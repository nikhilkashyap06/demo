import { SectionHeading } from "@/components/section-heading";
import { getSiteContent } from "@/lib/content";
import { Hero } from "@/components/hero";


export default function AboutPage() {
  const content = getSiteContent();
  const about = content?.about || {
    hero: {
      title: "About ION Green",
      description: "Leading innovator in energy storage solutions",
      tagline: "Powering a Sustainable Future"
    },
    stats: [],
    timeline: [],
    values: [],
    markets: []
  };
  return (
    <>
      <Hero page="about" />
      <div className="relative z-10 mx-auto -mt-16 max-w-5xl px-4 text-center md:px-6">
        <div className="inline-block rounded-2xl bg-white/90 px-8 py-6 shadow-lg backdrop-blur-sm border-2 border-green-100">
          <h1 className="text-3xl font-bold text-green-700 sm:text-4xl bg-gradient-to-r from-green-600 to-green-800 bg-clip-text text-transparent">{about.hero.title}</h1>
          <p className="mt-2 text-slate-700">{about.hero.description}</p>
        </div>
      </div>

      <section className="bg-white py-12 md:py-16">
        <div className="mx-auto max-w-6xl px-4 md:px-6">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-green-700 sm:text-4xl relative inline-block">
              <span className="relative z-10">About Company</span>
              <span className="absolute bottom-1 left-0 w-full h-3 bg-green-100 -z-0 opacity-70"></span>
            </h2>
            <div className="mx-auto mt-8 max-w-4xl space-y-6 text-left text-slate-700">
              <p>ION Green is a leading innovator in the energy sector, delivering advanced battery energy storage systems to 100+ countries. With a strong focus on innovation and sustainability, we are committed to providing high-quality energy storage solutions that power a cleaner, more efficient future.</p>
              <p>Our state-of-the-art manufacturing facility is equipped with advanced technology and staffed by a team of experienced professionals dedicated to delivering reliable and efficient energy storage systems. We take pride in our commitment to quality, safety, and environmental responsibility in every product we create.</p>
              <p>At ION Green, we understand the growing need for sustainable energy solutions. Our products are designed to meet the highest industry standards while addressing the unique energy challenges of today's world. From residential to commercial applications, our BESS solutions are helping to transform the way energy is stored and utilized across India.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-slate-50 py-16">
        <div className="mx-auto max-w-6xl px-4 md:px-6">
          <SectionHeading
            eyebrow="About ION Green"
            title="Who We Are"
            description="Innovating safe, efficient energy storage for homes, businesses, and utilities."
            align="center"
          />
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-6xl px-4 md:px-6">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-5">
            {about.stats.map((stat) => (
              <div key={stat.label} className="rounded-3xl border border-slate-100 p-6 text-center shadow-sm">
                <p className="text-3xl font-semibold text-slate-900">{stat.value}</p>
                <p className="mt-1 text-xs uppercase tracking-[0.3em] text-slate-500">{stat.label}</p>
                {stat.helper ? <p className="mt-2 text-xs text-slate-500">{stat.helper}</p> : null}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-slate-50 py-20">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 md:grid-cols-[2fr,3fr] md:px-6">
          <div className="space-y-6">
            <SectionHeading
              eyebrow="About ION Green"
              title="One-stop integrated energy storage solution provider"
              description="Five production bases across China deliver modular ESS solutions for manufacturing facilities, hospitals, municipal infrastructure, and residential communities."
              align="left"
            />
            <div className="rounded-3xl border border-slate-100 bg-white p-6 shadow-md">
              <h3 className="text-lg font-semibold text-green-700">Global Mission</h3>
              <p className="mt-3 text-sm text-slate-600">
                We help customers optimize energy efficiency, cut costs, and embrace sustainability with safe and
                intelligent battery storage technology.
              </p>
              <ul className="mt-4 space-y-2 text-sm text-slate-600">
                <li>• Utility-scale BESS containers up to 5.015MWh</li>
                <li>• Hybrid C&I solutions enabling peak shaving & backup power</li>
                <li>• Residential all-in-one systems with hybrid inverters</li>
              </ul>
            </div>
            
            
          </div>
          <div className="grid gap-6 md:grid-cols-2">
            {about.values.map((value) => (
              <article key={value.title} className="rounded-3xl border border-slate-100 bg-white p-6 shadow-inner">
                <p className="text-xs font-semibold uppercase tracking-[0.3em] text-green-500">Value</p>
                <h3 className="mt-3 text-lg font-semibold text-green-700">{value.title}</h3>
                <p className="mt-2 text-sm text-slate-600">{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white py-20">
        <div className="mx-auto max-w-6xl px-4 md:px-6">
          <SectionHeading
            eyebrow="Milestones"
            title="From solar thermal roots to global ESS leader"
            description="A 25-year journey of continuous innovation and manufacturing scale."
            align="left"
          />
          <div className="mt-12 space-y-4">
            {about.timeline.map((entry) => (
              <div
                key={entry.year}
                className="flex flex-col gap-3 rounded-3xl border border-slate-100 bg-slate-50/60 p-6 shadow-sm md:flex-row md:items-center md:justify-between"
              >
                <p className="text-2xl font-bold text-green-700">{entry.year}</p>
                <p className="text-sm text-slate-600">{entry.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white py-20">
        <div className="mx-auto max-w-6xl px-4 md:px-6">
          <SectionHeading
            eyebrow="Technical Expert"
            title="Our Technical Expertise"
            description="A team of experienced professionals dedicated to innovation and excellence in energy storage solutions."
            align="left"
          />
          <div className="mt-12 space-y-6">
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              {/* Technical Expert Card 1 */}
              <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-md">
                <h3 className="text-lg font-semibold text-green-700">Advanced R&D</h3>
                <p className="mt-3 text-sm text-slate-600">
                  Our dedicated R&D team continuously works on developing cutting-edge energy storage technologies and improving existing solutions.
                </p>
              </div>

              {/* Technical Expert Card 2 */}
              <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-md">
                <h3 className="text-lg font-semibold text-green-700">Quality Assurance</h3>
                <p className="mt-3 text-sm text-slate-600">
                  Rigorous testing and quality control processes ensure that every product meets international standards and exceeds customer expectations.
                </p>
              </div>

              {/* Technical Expert Card 3 */}
              <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-md">
                <h3 className="text-lg font-semibold text-green-700">Custom Solutions</h3>
                <p className="mt-3 text-sm text-slate-600">
                  We provide tailored energy storage solutions designed to meet specific customer requirements and application needs.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-slate-950 py-20 text-white">
        <div className="mx-auto max-w-6xl px-4 md:px-6">
          <SectionHeading
            eyebrow="Global Markets"
            title="Trusted by partners in 100+ countries"
            description="ION Green energy storage has passed UL9540, UL1973, CB/CE, and CEI-021 certifications for worldwide deployment."
            align="left"
            tone="light"
          />
          <div className="mt-10 flex flex-wrap gap-3">
            {about.markets.map((market) => (
              <span
                key={market}
                className="rounded-full border border-white/30 px-4 py-2 text-sm text-white/80"
              >
                {market}
              </span>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}


























