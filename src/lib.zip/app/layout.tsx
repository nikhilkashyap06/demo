import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { FloatingContactPanel } from "@/components/floating-contact-panel";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ION Green Energy Storage Systems",
  description:
    "ION Green BESS clone – commercial, industrial, and residential energy storage systems from 5kWh to 5MWh.",
  metadataBase: new URL("https://iongreen.itmingo.com"),
  openGraph: {
    title: "ION Green Energy Storage Systems",
    description:
      "One-stop ESS integrator delivering rack-mounted, hybrid, and containerized battery solutions.",
    url: "https://iongreen.itmingo.com",
    siteName: "ION Green Energy",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${geistSans.variable} ${geistMono.variable} bg-white antialiased`} suppressHydrationWarning>
        <SiteHeader />
        <main>{children}</main>
        <SiteFooter />
        <FloatingContactPanel />
      </body>
    </html>
  );
}
