import { NewsFeed } from "@/components/news-feed";
import { Hero } from "@/components/hero";

export default function NewsPage() {
  return (
    <>
      <Hero page="news">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white sm:text-5xl md:text-6xl">
            Company News & Events
          </h1>
          <p className="mx-auto mt-6 max-w-3xl text-lg text-white/90 md:text-xl">
            Stay current with exhibitions, product launches, and strategic partnerships.
          </p>
        </div>
      </Hero>
      <NewsFeed limit={500} />
    </>
  );
}

