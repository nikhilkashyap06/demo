// src/app/page.tsx
import { Hero } from "@/components/hero";
import { StatsStrip } from "@/components/stats-strip";
import { BetterLifeSection } from "@/components/better-life-section";
import { DynamicProductShowcase } from "@/components/dynamic-product-showcase";
import { DynamicSolutionsGrid } from "@/components/dynamic-solutions-grid";
import { CertificationBar } from "@/components/certification-bar";
import { SupportResources } from "@/components/support-resources";
import { NewsFeed } from "@/components/news-feed";
import { ContactChannels } from "@/components/contact-channels";
import { CTAPanel } from "@/components/cta-panel";
import { WhyChooseUs } from "@/components/why-choose-us";
import { SolarEnergySection } from "@/components/solar-energy-section";
import GlobalCoverageSection from "@/components/global-coverage-section";
import { PowerIonGreenSidebar } from "@/components/power-ion-green-sidebar";
import { HomepageSidebars } from "@/components/homepage-sidebars";
import { DynamicLabEquipmentSection } from "@/components/dynamic-lab-equipment-section";
import { dbService } from "@/lib/db-service";

// Enable ISR (Incremental Static Regeneration) with a revalidation period
export const revalidate = 60; // Revalidate at most every 60 seconds

interface HeroSlide {
  id: number;
  title: string;
  description: string;
  cta_label: string;
  cta_href: string;
  image_url: string;
  position: number;
  is_active: boolean;
}

export default async function Home() {
  // Fetch dynamic hero slides
  let heroSlides: HeroSlide[] | undefined = undefined;
  try {
    const slides = await dbService.getHeroSlides();
    // Transform to match the expected format
    heroSlides = slides.map(slide => ({
      id: slide.id,
      title: slide.title,
      description: slide.description,
      cta_label: slide.cta_label,
      cta_href: slide.cta_href,
      image_url: slide.image_url,
      position: slide.position,
      is_active: slide.is_active
    }));
  } catch (error) {
    console.error("Failed to fetch hero slides:", error);
    // Fall back to static slides if there's an error
    heroSlides = undefined;
  }

  return (
    <>
      <Hero page="home" slides={heroSlides} />
      <StatsStrip />
      <BetterLifeSection />
      <DynamicProductShowcase />
      <PowerIonGreenSidebar />
      <SolarEnergySection />
      <DynamicSolutionsGrid />
      <GlobalCoverageSection />
      
      <CertificationBar />
      <DynamicLabEquipmentSection />
      <SupportResources />
      <WhyChooseUs />
      <HomepageSidebars />
      <NewsFeed limit={4} showViewAll />
      <ContactChannels />
      <CTAPanel />
    </>
  );
}
