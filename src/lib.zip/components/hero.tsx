"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { getSiteContent } from "@/lib/content";
import { cn } from "@/lib/utils";

const hero = getSiteContent().hero;

interface StaticHeroSlide {
  title: string;
  description: string;
  ctaLabel: string;
  ctaHref: string;
  image: string;
}

interface DynamicHeroSlide {
  id: number;
  title: string;
  description: string;
  cta_label: string;
  cta_href: string;
  image_url: string;
  position: number;
}

type HeroSlide = StaticHeroSlide | DynamicHeroSlide;

interface HeroProps extends React.HTMLAttributes<HTMLElement> {
  page?: string;
  children?: React.ReactNode;
  slides?: DynamicHeroSlide[]; // Add slides prop for dynamic content
}

// Type guard to check if slide is dynamic
function isDynamicSlide(slide: HeroSlide): slide is DynamicHeroSlide {
  return 'id' in slide && 'image_url' in slide;
}

export function Hero({ page = 'home', children, className, slides: externalSlides, ...props }: HeroProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  // Use external slides if provided, otherwise use static content
  const slides = externalSlides || hero.slides;
  
  // Define background images for different pages using local images
  const pageBackgrounds = {
    home: '/1/ion1.png',
    about: '/1/ion2.png',
    products: '/1/ion3.png',
    solutions: '/1/ion4.png',
    'case': '/1/ion5.png',
    'case-studies': '/1/ion6.png',
    news: '/2/green.png',
    contact: '/3/green1.png',
    support: '/3/green2.png',
    'lab-equipment': '/3/green3.png',
  };
  
  const currentBackground = pageBackgrounds[page as keyof typeof pageBackgrounds] || pageBackgrounds.home;

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [slides.length]);

  const goToPrevSlide = () => {
    setActiveIndex((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const goToNextSlide = () => {
    setActiveIndex((prev) => (prev + 1) % slides.length);
  };

  // Helper function to get slide properties
  const getSlideImageUrl = (slide: HeroSlide) => {
    return isDynamicSlide(slide) ? slide.image_url : `${slide.image}?x-oss-process=image/quality,q_85`;
  };

  const getSlideCtaHref = (slide: HeroSlide) => {
    return isDynamicSlide(slide) ? slide.cta_href : slide.ctaHref;
  };

  const getSlideCtaLabel = (slide: HeroSlide) => {
    return isDynamicSlide(slide) ? slide.cta_label : slide.ctaLabel;
  };

  return (
    <section className={cn("relative overflow-hidden text-white", className)} {...props}>
      {/* Navigation Arrows */}
      {page === 'home' && slides.length > 1 && (
        <>
          <button
            onClick={goToPrevSlide}
            className="absolute left-4 top-1/2 z-20 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-black/30 text-white backdrop-blur-sm transition hover:bg-black/50"
            aria-label="Previous slide"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <button
            onClick={goToNextSlide}
            className="absolute right-4 top-1/2 z-20 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-black/30 text-white backdrop-blur-sm transition hover:bg-black/50"
            aria-label="Next slide"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </>
      )}
      
      <div className="relative h-[640px] w-full">
        {page === 'home' ? (
          <>
            {slides.map((slide, index) => (
              <div key={getSlideImageUrl(slide) || index} className="absolute inset-0" aria-hidden={activeIndex !== index}>
                <Image
                  src={getSlideImageUrl(slide)}
                  alt={slide.title}
                  fill
                  className={cn(
                    "object-cover transition-opacity duration-700",
                    activeIndex === index ? "opacity-100" : "opacity-0"
                  )}
                  priority={index === 0}
                />
                <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/75 to-slate-900/5" />
              </div>
            ))}
          </>
        ) : (
          <div className="absolute inset-0">
            <Image
              src={currentBackground}
              alt={`${page} background`}
              fill
              className="object-cover"
              priority
              quality={85}
              sizes="100vw"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/75 to-slate-900/5" />
          </div>
        )}
        <div className="relative z-10 mx-auto flex h-full max-w-6xl flex-col justify-center px-4 py-16 md:px-6">
          {children || (
            <div className="space-y-6">
              <div className="max-w-2xl space-y-6">
                <p className="text-sm font-semibold uppercase tracking-[0.3em] text-green-300">
                  {hero.eyebrow}
                </p>
                <div className="space-y-4" aria-live="polite">
                  <h1 className="text-4xl font-semibold leading-tight text-white sm:text-5xl">
                    {slides[activeIndex]?.title || 'Welcome to Ion Green'}
                  </h1>
                  <p className="text-lg text-white/80">
                    {slides[activeIndex]?.description || 'Innovative energy solutions for a sustainable future'}
                  </p>
                </div>
                <div className="flex flex-wrap gap-4">
                  <Link
                    href={getSlideCtaHref(slides[activeIndex]) || '/contact'}
                    className="rounded-full bg-green-500 px-5 py-3 text-sm font-semibold text-slate-900 transition hover:bg-green-400"
                  >
                    {getSlideCtaLabel(slides[activeIndex]) || 'Get Started'}
                  </Link>
                  <Link
                    href="/support"
                    className="rounded-full border border-white/40 px-5 py-3 text-sm font-semibold text-white transition hover:border-white hover:text-green-200"
                  >
                    Download Brochure
                  </Link>
                </div>
                <div className="flex gap-3">
                  {slides.map((_, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => setActiveIndex(index)}
                      className={cn(
                        "h-2 w-2 rounded-full transition-colors",
                        activeIndex === index ? "bg-white" : "bg-white/30"
                      )}
                      aria-label={`Go to slide ${index + 1}`}
                    />
                  ))}
                </div>
              </div>
              {page === 'home' && hero.stats && (
                <div className="mt-16 grid gap-6 sm:grid-cols-2 md:grid-cols-4">
                  {hero.stats.map((stat: any) => (
                    <div key={stat.label} className="rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur">
                      <p className="text-3xl font-semibold text-white">{stat.value}</p>
                      <p className="text-sm text-white/70">{stat.label}</p>
                      {stat.helper && <p className="text-xs text-white/50">{stat.helper}</p>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}