import Image from "next/image";

export function HomepageSidebars() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Left Column - ION Green Related Content */}
          <div className="bg-slate-50 rounded-2xl p-8 shadow-sm border border-slate-100">
            <div className="flex flex-col h-full">
              <h3 className="text-2xl font-bold text-slate-900 mb-4">ION Green Excellence</h3>
              <p className="text-slate-600 mb-4">
                At ION Green, we're committed to delivering cutting-edge battery energy storage solutions designed for maximum efficiency, safety, and longevity. Our products are engineered to meet the highest industry standards.
              </p>
              <p className="text-slate-600 mb-4">
                With global deployments across residential, commercial, and industrial sectors, our technology ensures reliable performance in diverse environments and applications.
              </p>
              <p className="text-slate-600 mb-4">
                Each product undergoes rigorous testing and quality assurance processes to guarantee optimal performance and customer satisfaction.
              </p>
              <div className="mt-6 flex-grow">
                <h4 className="text-lg font-semibold text-slate-900 mb-3">Why Choose ION Green:</h4>
                <ul className="space-y-2 text-slate-600">
                  <li className="flex items-start">
                    <span className="mr-2 text-green-600">✓</span>
                    <span>High-efficiency lithium-ion technology</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 text-green-600">✓</span>
                    <span>Intelligent energy management systems</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 text-green-600">✓</span>
                    <span>Scalable modular designs</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 text-green-600">✓</span>
                    <span>Comprehensive warranty and support</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 text-green-600">✓</span>
                    <span>Global manufacturing standards</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 text-green-600">✓</span>
                    <span>24/7 technical support</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Right Column - Image Card */}
          <div className="bg-slate-50 rounded-2xl p-8 shadow-sm border border-slate-100">
            <div className="flex flex-col h-full">
              <h3 className="text-2xl font-bold text-slate-900 mb-4">Innovation & Sustainability</h3>
              <div className="flex-grow flex items-center justify-center">
                <div className="relative w-full h-80 rounded-xl overflow-hidden shadow-lg">
                  <Image
                    src="/3/title1.png"
                    alt="ION Green Excellence"
                    fill
                    className="object-contain"
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  />
                </div>
              </div>
              <div className="mt-6">
                <p className="text-slate-600 text-center">
                  Advanced energy storage solutions for a sustainable future
                </p>
              </div>
            </div>
          </div>

          {/* Left Column - Additional Content */}
          <div className="bg-slate-50 rounded-2xl p-8 shadow-sm border border-slate-100">
            <div className="flex flex-col h-full">
              <h3 className="text-2xl font-bold text-slate-900 mb-4">Commitment to Innovation</h3>
              <p className="text-slate-600 mb-4">
                Our commitment to innovation drives us to develop sustainable energy solutions that address the evolving needs of our global customers. We continuously invest in research and development to stay ahead of industry trends.
              </p>
              <p className="text-slate-600 mb-4">
                With a focus on environmental responsibility, our products help reduce carbon footprints while maximizing energy efficiency and cost savings.
              </p>
              <p className="text-slate-600 mb-4">
                Our global team of engineers and researchers work tirelessly to push the boundaries of energy storage technology.
              </p>
              <div className="mt-6 flex-grow">
                <h4 className="text-lg font-semibold text-slate-900 mb-3">Our Commitment:</h4>
                <ul className="space-y-2 text-slate-600">
                  <li className="flex items-start">
                    <span className="mr-2 text-green-600">✓</span>
                    <span>Continuous innovation and R&D</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 text-green-600">✓</span>
                    <span>Environmental sustainability</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 text-green-600">✓</span>
                    <span>Global manufacturing standards</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 text-green-600">✓</span>
                    <span>Customer-centric solutions</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 text-green-600">✓</span>
                    <span>Quality assurance processes</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 text-green-600">✓</span>
                    <span>Ethical business practices</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Right Column - Second Image Card */}
          <div className="bg-slate-50 rounded-2xl p-8 shadow-sm border border-slate-100">
            <div className="flex flex-col h-full">
              <h3 className="text-2xl font-bold text-slate-900 mb-4">Sustainable Solutions</h3>
              <div className="flex-grow flex items-center justify-center">
                <div className="relative w-full h-80 rounded-xl overflow-hidden shadow-lg">
                  <Image
                    src="/3/title2.png"
                    alt="Innovation & Sustainability"
                    fill
                    className="object-contain"
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  />
                </div>
              </div>
              <div className="mt-6">
                <p className="text-slate-600 text-center">
                  Building a greener tomorrow with clean energy technology
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}