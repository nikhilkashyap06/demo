"use client";

import { useState } from "react";
import Link from "next/link";
import { cn } from "@/lib/utils";

interface NavItem {
  label: string;
  href: string;
  description?: string;
  items?: NavItem[];
}

interface NavDropdownProps {
  item: NavItem;
  isActive: boolean;
}

export function NavDropdown({ item, isActive }: NavDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div
      className="relative"
      onMouseEnter={() => setIsOpen(true)}
      onMouseLeave={() => setIsOpen(false)}
    >
      <button
        className={cn(
          "flex items-center gap-1 transition hover:text-green-300",
          isActive ? "text-green-400" : "text-white/80"
        )}
      >
        {item.label}
        <svg
          className={`h-4 w-4 transition-transform ${isOpen ? 'rotate-180' : ''}`}
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {isOpen && item.items && (
        <div className="absolute left-0 top-full mt-2 w-64 rounded-lg border border-white/10 bg-slate-900/95 p-4 shadow-lg backdrop-blur">
          <div className="space-y-2">
            {item.description && (
              <p className="mb-2 text-sm text-white/70">{item.description}</p>
            )}
            <div className="grid gap-1">
              {item.items.map((subItem) => (
                <Link
                  key={subItem.href}
                  href={subItem.href}
                  className="block rounded-md px-3 py-2 text-sm text-white/90 transition hover:bg-white/10 hover:text-green-300"
                >
                  <div className="font-medium">{subItem.label}</div>
                  {subItem.description && (
                    <p className="text-xs text-white/60">{subItem.description}</p>
                  )}
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
