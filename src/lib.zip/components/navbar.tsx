import Link from 'next/link';
import { getSiteContent } from '@/lib/content';

export function Navbar() {
  const { navItems } = getSiteContent();

  return (
    <header className="bg-white/90 backdrop-blur-md shadow-md sticky top-0 z-50 border-b border-gray-100">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" aria-label="Global">
        <div className="flex justify-between h-20">
          <div className="flex items-center">
            <Link href="/" className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 transition-all duration-300">
              <span className="relative group">
              Ion Green
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-green-500 to-emerald-500 transition-all duration-300 group-hover:w-full"></span>
              </span>
            </Link>
          </div>
          
          <div className="hidden md:flex md:items-center md:space-x-6">
            {navItems.map((item) => (
              <div key={item.href} className="relative group">
                <Link 
                  href={item.href}
                  className="relative px-3 py-2.5 text-sm font-medium text-gray-700 hover:text-green-600 transition-colors duration-300 group"
                >
                  <span className="relative z-10 flex items-center">
                    <span className={`${item.items ? 'mr-1' : ''} group-hover:italic`}>
                      {item.label}
                    </span>
                    {item.items && (
                      <svg className="ml-1 h-4 w-4 transform transition-transform duration-200 group-hover:rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    )}
                  </span>
                  <span className="absolute bottom-1.5 left-3 right-3 h-0.5 bg-gradient-to-r from-green-400 to-emerald-400 transform scale-x-0 origin-left group-hover:scale-x-100 transition-transform duration-300"></span>
                </Link>
                
                {item.items && (
                  <div className="absolute left-1/2 transform -translate-x-1/2 mt-2 w-56 rounded-xl shadow-xl bg-white/95 backdrop-blur-sm ring-1 ring-gray-100 ring-opacity-10 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-10 overflow-hidden">
                    <div className="py-1.5">
                      {item.items.map((subItem, index) => (
                        <Link
                          key={subItem.href}
                          href={subItem.href}
                          className="block px-5 py-2.5 text-sm text-gray-600 hover:bg-gray-50/80 hover:text-green-600 transition-colors duration-200 group/item"
                        >
                          <span className="flex items-center">
                            <span className="w-1.5 h-1.5 rounded-full bg-green-400 opacity-0 group-hover/item:opacity-100 mr-2 transition-opacity duration-200"></span>
                            <span className="group-hover/item:translate-x-1 transition-transform duration-200">
                              {subItem.label}
                            </span>
                          </span>
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
          

        </div>
      </nav>
    </header>
  );
}
