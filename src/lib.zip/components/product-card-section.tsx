"use client";

import Image from "next/image";
import { useState } from "react";
import { DetailModal } from "@/components/detail-modal";

interface CardProps {
  image: string;
  title: string;
  description: string;
  detailedContent: string;
}

export function ProductCardSection() {
  // Sample data for the cards with detailed content
  const cards: CardProps[] = [
    {
      image: "/1/ion1.png",
      title: "Advanced Energy Storage",
      description: "Cutting-edge battery technology with high efficiency and long lifespan for residential and commercial applications.",
      detailedContent: "Our advanced energy storage systems utilize state-of-the-art lithium-ion battery technology, offering exceptional efficiency rates of up to 95%. With a lifespan of over 10 years and 8000+ charge cycles, these systems provide reliable power storage for both residential and commercial applications. The modular design allows for easy scalability, and our intelligent battery management system ensures optimal performance and safety at all times."
    },
    {
      image: "/1/ion2.png",
      title: "Smart Grid Integration",
      description: "Seamless integration with existing power grids for optimal energy distribution and management.",
      detailedContent: "Our smart grid integration technology enables seamless connectivity between your energy storage system and the existing power grid. This advanced solution provides real-time monitoring, automated load balancing, and intelligent energy distribution. With predictive analytics and machine learning algorithms, the system optimizes energy consumption patterns, reduces peak demand charges, and maximizes savings. The integration supports various communication protocols and can easily adapt to changing grid conditions."
    },
    {
      image: "/1/ion3.png",
      title: "Eco-Friendly Solutions",
      description: "Sustainable energy solutions that reduce carbon footprint and promote environmental responsibility.",
      detailedContent: "ION Green is committed to environmental sustainability through our eco-friendly energy solutions. Our systems are manufactured using recycled materials and RoHS-compliant components. During operation, they produce zero emissions and significantly reduce your carbon footprint. With a recyclability rate of over 95% at end-of-life, our products support circular economy principles. Additionally, our solutions help reduce dependence on fossil fuels and contribute to a cleaner, greener planet for future generations."
    },
    {
      image: "/1/ion4.png",
      title: "24/7 Monitoring",
      description: "Real-time monitoring and analytics to ensure optimal performance and quick issue resolution.",
      detailedContent: "Our comprehensive 24/7 monitoring system provides real-time insights into your energy storage system's performance. With cloud-based analytics and mobile app integration, you can monitor energy production, consumption, and storage from anywhere. The system sends instant alerts for any anomalies and provides predictive maintenance notifications. Advanced diagnostic tools help our technicians resolve issues quickly, ensuring maximum uptime. Detailed performance reports help you track savings and optimize energy usage patterns."
    }
  ];

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState({
    title: "",
    image: "",
    description: "",
    detailedContent: ""
  });

  const openModal = (item: CardProps) => {
    setSelectedItem(item);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Why Choose ION Green?</h2>
          <p className="text-lg text-slate-600 max-w-3xl mx-auto">
            Discover the advantages of our innovative energy storage solutions
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {cards.map((card, index) => (
            <div 
              key={index} 
              className="overflow-hidden border border-slate-200 rounded-lg hover:shadow-lg transition-shadow bg-slate-50"
            >
              <div className="relative h-48">
                <Image
                  src={card.image}
                  alt={card.title}
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-slate-900 mb-2">{card.title}</h3>
                <p className="text-slate-600 mb-4">{card.description}</p>
                
                <div className="flex justify-center gap-3 mt-6">
                  <button
                    onClick={() => openModal(card)}
                    className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors text-sm font-medium"
                  >
                    Read More
                  </button>
                  <a 
                    href="tel:+919202636627"
                    className="px-4 py-2 bg-white text-green-600 border border-green-600 rounded-md hover:bg-green-50 transition-colors text-sm font-medium"
                  >
                    Call Now
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Detail Modal */}
      <DetailModal
        isOpen={isModalOpen}
        onClose={closeModal}
        title={selectedItem.title}
        image={selectedItem.image}
        description={selectedItem.description}
        detailedContent={selectedItem.detailedContent}
      />
    </section>
  );
}
