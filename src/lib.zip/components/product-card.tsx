"use client";

import Image from "next/image";
import Link from "next/link";

interface ProductCardProps {
  id: number;
  name: string;
  slug: string;
  category: string;
  description?: string;
  imageUrl?: string;
  isFeatured?: boolean;
}

export function ProductCard({
  id,
  name,
  slug,
  category,
  description,
  imageUrl = "https://images.unsplash.com/photo-1509391366360-2e959784a276?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=85",
  isFeatured = false,
}: ProductCardProps) {
  return (
    <div className="group relative bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300">
      {isFeatured && (
        <div className="absolute top-2 right-2 bg-green-600 text-white text-xs font-bold px-2 py-1 rounded-full z-10">
          Featured
        </div>
      )}
      
      <div className="aspect-w-1 aspect-h-1 w-full overflow-hidden bg-gray-200">
        <Image
          src={imageUrl}
          alt={name}
          width={400}
          height={300}
          className="h-48 w-full object-cover object-center group-hover:opacity-90 transition-opacity"
          quality={85}
        />
      </div>
      
      <div className="p-4">
        <div className="text-sm font-medium text-green-600 mb-1">
          {category}
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">
          <Link href={`/products/${slug}`} className="hover:text-green-600 transition-colors">
            <span aria-hidden="true" className="absolute inset-0" />
            {name}
          </Link>
        </h3>
        
        {description && (
          <p className="mt-1 text-sm text-gray-600 line-clamp-2">
            {description}
          </p>
        )}
        
        <div className="mt-4 flex items-center gap-3">
          <Link
            href={`/products/${slug}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm font-medium text-green-600 hover:text-green-700 flex items-center"
          >
            View details
            <span className="ml-1">→</span>
          </Link>
          <a
            href="tel:+919202636627"
            aria-label="Call now"
            className="inline-flex items-center rounded-md border border-green-600 px-3 py-1.5 text-sm font-medium text-green-700 hover:bg-green-50"
          >
            Call Now
          </a>
        </div>
      </div>
    </div>
  );
}
